nama=input("Masukkan nama kamu:")
nama_panggilan=input("Masukan nama panggilan kamu:")
print("nama saya,"+nama)
print("kamu bisa panggil saya",nama_panggilan)
